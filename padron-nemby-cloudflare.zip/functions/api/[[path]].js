const enc = new TextEncoder();
const J = (d, s = 200) => new Response(JSON.stringify(d), { status: s, headers: { "content-type": "application/json", "cache-control": "no-store" } });
const b64u = buf => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const hex = buf => [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
const same = (a, b) => { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; };
const normCI = v => String(v ?? "").replace(/\D/g, "").replace(/^0+/, "");
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function sign(data, secret) {
  const k = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return b64u(await crypto.subtle.sign("HMAC", k, enc.encode(data)));
}
async function hash(pw, salt) {
  const k = await crypto.subtle.importKey("raw", enc.encode(String(pw)), "PBKDF2", false, ["deriveBits"]);
  return hex(await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: enc.encode(salt), iterations: 100000 }, k, 256));
}
const rnd = () => hex(crypto.getRandomValues(new Uint8Array(16)));
const pArr = r => r ? [r.ap, r.nom, r.fn, r.cod, r.dsec, r.loc, r.dir, r.faf] : null;
const vOut = r => ({ ci: r.ci, nombre: r.nombre, tel: r.tel, nota: r.nota, fecha: r.fecha, por: r.por, hist: JSON.parse(r.hist || "[]") });
const PCOLS = "p.ap,p.nom,p.fn,p.cod,p.dsec,p.loc,p.dir,p.faf";

export async function handle(req, env) {
  const DB = env.DB, url = new URL(req.url), m = req.method;
  const path = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean);
  const body = ["POST", "PUT", "PATCH"].includes(m) ? await req.json().catch(() => ({})) : {};
  const one = (sql, ...a) => DB.prepare(sql).bind(...a).first();
  const all = async (sql, ...a) => (await DB.prepare(sql).bind(...a).all()).results;
  const run = (sql, ...a) => DB.prepare(sql).bind(...a).run();
  const secret = env.AUTH_SECRET;
  if (!secret || !DB) return J({ error: "Falta configurar AUTH_SECRET y/o el enlace a la base de datos (DB)" }, 500);
  const mkUser = async (u, pw, nombre, role) => {
    const salt = rnd();
    await run("INSERT INTO users(user,nombre,role,activo,salt,hash,creado) VALUES(?,?,?,1,?,?,?)", u, nombre, role, salt, await hash(pw, salt), new Date().toISOString());
    return one("SELECT * FROM users WHERE user=?", u);
  };

  /* ---- Login ---- */
  if (path[0] === "login" && m === "POST") {
    const u = String(body.user || "").trim().toLowerCase();
    let rec = await one("SELECT * FROM users WHERE user=?", u);
    if (!rec && env.ADMIN_USER && u === env.ADMIN_USER.toLowerCase() && body.pass === env.ADMIN_PASSWORD)
      rec = await mkUser(u, body.pass, "Administrador", "admin");
    if (!rec || !rec.activo || !same(await hash(body.pass || "", rec.salt), rec.hash)) { await sleep(600); return J({ error: "Usuario o contraseña incorrectos" }, 401); }
    const p = b64u(enc.encode(JSON.stringify({ u, exp: Date.now() + 12 * 3600e3 })));
    return J({ token: p + "." + await sign(p, secret) });
  }

  /* ---- Autenticación ---- */
  const [p, sg] = (req.headers.get("authorization") || "").replace(/^Bearer /, "").split(".");
  let me = null;
  if (p && sg && same(sg, await sign(p, secret))) {
    try { const d = JSON.parse(atob(p.replace(/-/g, "+").replace(/_/g, "/"))); if (d.exp > Date.now()) me = await one("SELECT * FROM users WHERE user=?", d.u); } catch {}
  }
  if (!me || !me.activo) return J({ error: "No autorizado" }, 401);
  const admin = me.role === "admin";
  const needAdmin = () => admin ? null : J({ error: "Solo administradores" }, 403);
  const meta = async () => { const r = await one("SELECT v FROM meta WHERE k='meta'"); return r ? JSON.parse(r.v) : { target: "", secciones: {} }; };
  if (path[0] === "me") return J({ user: me.user, nombre: me.nombre, role: me.role, meta: await meta() });

  /* ---- Consulta por cédula ---- */
  if (path[0] === "ci" && path[1]) {
    const ci = normCI(path[1]);
    const [pr, v] = await Promise.all([one(`SELECT ${PCOLS} FROM padron p WHERE ci=?`, ci), one("SELECT * FROM votantes WHERE ci=?", ci)]);
    return J({ ci, p: pArr(pr), v: v ? vOut(v) : null });
  }

  /* ---- Votantes ---- */
  if (path[0] === "votantes") {
    if (m === "GET" && !path[1]) {
      const rows = await all(`SELECT v.*, ${PCOLS} FROM votantes v LEFT JOIN padron p ON p.ci=v.ci`);
      return J(rows.map(r => ({ ...vOut(r), p: r.cod != null ? pArr(r) : null })));
    }
    if (path[1] === "bulk" && m === "POST") {
      const cis = [...new Set((body.cis || []).map(normCI).filter(c => c.length >= 4))];
      if (!cis.length) return J({ agregados: 0, repetidos: 0 });
      const r = await run("INSERT OR IGNORE INTO votantes(ci,fecha,por,sec_ref) SELECT value,?,?,(SELECT cod FROM padron WHERE ci=value) FROM json_each(?)", new Date().toISOString(), me.user, JSON.stringify(cis));
      const n = r.meta.changes; return J({ agregados: n, repetidos: cis.length - n });
    }
    const ci = normCI(path[1]); if (!ci) return J({ error: "Cédula inválida" }, 400);
    const old = await one("SELECT * FROM votantes WHERE ci=?", ci);
    if (m === "PUT") {
      const f = (k, n) => String(body[k] ?? old?.[k] ?? "").slice(0, n);
      if (old) await run("UPDATE votantes SET nombre=?,tel=?,nota=? WHERE ci=?", f("nombre", 120), f("tel", 40), f("nota", 500), ci);
      else await run("INSERT INTO votantes(ci,nombre,tel,nota,fecha,por,sec_ref) VALUES(?,?,?,?,?,?,(SELECT cod FROM padron WHERE ci=?))", ci, f("nombre", 120), f("tel", 40), f("nota", 500), new Date().toISOString(), me.user, ci);
      return J(vOut(await one("SELECT * FROM votantes WHERE ci=?", ci)));
    }
    if (m === "DELETE") {
      if (old && old.por !== me.user && !admin) return J({ error: "Solo quien lo registró o un administrador puede quitarlo" }, 403);
      await run("DELETE FROM votantes WHERE ci=?", ci); return J({ ok: true });
    }
  }

  /* ---- Metadatos ---- */
  if (path[0] === "meta" && m === "POST") {
    const e = needAdmin(); if (e) return e;
    const mt = await meta();
    if (body.target !== undefined) mt.target = String(body.target).trim();
    if (body.secciones) mt.secciones = { ...mt.secciones, ...body.secciones };
    await run("INSERT INTO meta(k,v) VALUES('meta',?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", JSON.stringify(mt));
    return J(mt);
  }

  /* ---- Padrón (admin): begin → batch… → end ---- */
  if (path[0] === "padron") {
    const e = needAdmin(); if (e) return e;
    if (path[1] === "begin" && m === "POST") {
      await run("UPDATE votantes SET sec_ref=(SELECT cod FROM padron WHERE padron.ci=votantes.ci)");
      await run("DELETE FROM padron WHERE cod IN (SELECT value FROM json_each(?))", JSON.stringify((body.replace || []).map(String)));
      return J({ ok: true });
    }
    if (path[1] === "batch" && m === "POST") {
      const recs = (body.records || []).map(r => r.map(x => String(x ?? "")));
      if (recs.length) await run("INSERT OR REPLACE INTO padron(ci,ap,nom,fn,cod,dsec,loc,dir,faf) SELECT json_extract(value,'$[0]'),json_extract(value,'$[1]'),json_extract(value,'$[2]'),json_extract(value,'$[3]'),json_extract(value,'$[4]'),json_extract(value,'$[5]'),json_extract(value,'$[6]'),json_extract(value,'$[7]'),json_extract(value,'$[8]') FROM json_each(?)", JSON.stringify(recs));
      return J({ ok: true, n: recs.length });
    }
    if (path[1] === "end" && m === "POST") {
      const rows = await all("SELECT v.ci, v.hist, v.sec_ref a, p.cod b FROM votantes v LEFT JOIN padron p ON p.ci=v.ci WHERE COALESCE(v.sec_ref,'')<>COALESCE(p.cod,'')");
      const f = new Date().toISOString(), st = [];
      for (const r of rows) {
        const t = !r.a ? `Ahora figura afiliado en Secc. ${r.b}` : !r.b ? `Ya no figura en el padrón (estaba en Secc. ${r.a})` : `Pasó de Secc. ${r.a} a Secc. ${r.b}`;
        const h = [{ f, t }, ...JSON.parse(r.hist || "[]")].slice(0, 5);
        st.push(DB.prepare("UPDATE votantes SET hist=?, sec_ref=? WHERE ci=?").bind(JSON.stringify(h), r.b, r.ci));
      }
      for (let i = 0; i < st.length; i += 50) await DB.batch(st.slice(i, i + 50));
      return J({ ok: true, cambios: rows.length });
    }
    if (path[1] === "export" && m === "GET") {
      const lim = Math.min(+url.searchParams.get("limit") || 5000, 10000);
      const rows = await all("SELECT ci,ap,nom,fn,cod,dsec,loc,dir,faf FROM padron WHERE ci>? ORDER BY ci LIMIT ?", url.searchParams.get("after") || "", lim);
      return J({ rows: rows.map(r => [r.ci, r.ap, r.nom, r.fn, r.cod, r.dsec, r.loc, r.dir, r.faf]) });
    }
  }

  /* ---- Usuarios (admin) ---- */
  if (path[0] === "usuarios") {
    const e = needAdmin(); if (e) return e;
    const pub = u => ({ user: u.user, nombre: u.nombre, role: u.role, activo: !!u.activo });
    if (m === "GET") return J((await all("SELECT user,nombre,role,activo FROM users ORDER BY user")).map(pub));
    if (m === "POST") {
      const u = String(body.user || "").trim().toLowerCase();
      if (!/^[a-z0-9._-]{3,30}$/.test(u)) return J({ error: "Usuario: 3-30 caracteres (letras, números . _ -)" }, 400);
      if (String(body.pass || "").length < 8) return J({ error: "La contraseña debe tener al menos 8 caracteres" }, 400);
      if (await one("SELECT 1 x FROM users WHERE user=?", u)) return J({ error: "Ese usuario ya existe" }, 409);
      return J(pub(await mkUser(u, body.pass, String(body.nombre || u).slice(0, 80), body.role === "admin" ? "admin" : "equipo")));
    }
    if (m === "PATCH" && path[1]) {
      const u = path[1].toLowerCase(); if (!await one("SELECT 1 x FROM users WHERE user=?", u)) return J({ error: "No existe" }, 404);
      if (body.activo !== undefined) { if (u === me.user) return J({ error: "No puede desactivarse a sí mismo" }, 400); await run("UPDATE users SET activo=? WHERE user=?", body.activo ? 1 : 0, u); }
      if (body.pass) { if (String(body.pass).length < 8) return J({ error: "Mínimo 8 caracteres" }, 400); const s = rnd(); await run("UPDATE users SET salt=?,hash=? WHERE user=?", s, await hash(body.pass, s), u); }
      return J(pub(await one("SELECT * FROM users WHERE user=?", u)));
    }
  }
  return J({ error: "Ruta no encontrada" }, 404);
}
export const onRequest = ({ request, env }) => handle(request, env);
