# Padrón ANR Ñemby – Cloudflare Pages + D1

Estructura:
  public/index.html           la página
  functions/api/[[path]].js   el servidor
  schema.sql                  tablas de la base de datos

## Pasos (todo desde dash.cloudflare.com, cuenta gratuita)
1. Base de datos: Storage & Databases → D1 → Create database (nombre: padron-nemby).
   Abra la pestaña "Console", pegue TODO el contenido de schema.sql y ejecute.
2. Suba esta carpeta a un repositorio PRIVADO de GitHub.
3. Workers & Pages → Create → Pages → Connect to Git → elija el repositorio.
   Build command: (vacío)   Build output directory: public   → Deploy.
4. En el proyecto: Settings → Bindings → Add → D1 database
   Variable name: DB   → seleccione padron-nemby.
5. Settings → Variables and secrets → agregue (tipo Secret):
   AUTH_SECRET     texto largo al azar (32+ caracteres)
   ADMIN_USER      ej: admin
   ADMIN_PASSWORD  contraseña inicial (mín. 8 caracteres)
6. Deployments → Retry/Redeploy (para que tome el binding y las variables).
7. Abra el link *.pages.dev, ingrese con el administrador, cargue las planillas
   en "Padrón" y cree los usuarios del equipo en "Usuarios".

Alternativa sin GitHub: instalar Node y ejecutar
  npx wrangler pages deploy public --project-name padron-nemby
(los nombres de los menús de Cloudflare pueden variar un poco con el tiempo)
